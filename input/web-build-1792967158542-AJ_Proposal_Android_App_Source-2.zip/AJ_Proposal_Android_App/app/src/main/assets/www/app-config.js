// Android app configuration. Offline mode keeps the proposal usable without hosting.
// To enable email notifications, deploy the Netlify function and set offlineMode=false
// and responseEndpoint to your deployed function URL. Never put API secrets here.
window.AJ_CONFIG = {
  offlineMode: true,
  responseEndpoint: ''
};
