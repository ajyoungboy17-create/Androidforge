# A Little Question from AJ — Android app project

This Android Studio project packages the existing proposal website in a native Android WebView. The HTML, CSS, JavaScript, and both MP3 files are bundled inside the app, so the main experience and audio do not require a website to be hosted.

## Build an APK

1. Install Android Studio on a computer and allow it to install Android SDK Platform 35 and a compatible JDK.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `AJ_Proposal_Android_App` folder.
4. Wait for Gradle sync to finish. Internet access is needed the first time to download Gradle/Android dependencies.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. When the build succeeds, Android Studio will show a link to the APK. The usual output path is `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy the APK to your Android phone, open it, and approve installation from that source if Android asks.

## Important response behavior

The app defaults to offline mode. The proposal experience, audio, buttons, and final screens work without a hosted website. When a recipient answers, the choice is saved in the app's local WebView storage on that device. **It does not send an email or transmit the answer to AJ** in this default mode.

To enable email notifications, deploy the Netlify function from the original project and set `offlineMode: false` and `responseEndpoint` in `app/src/main/assets/www/app-config.js` to the full HTTPS URL of the deployed function. Configure `AJ_NOTIFICATION_EMAIL`, `RESEND_API_KEY`, and `RESEND_FROM_EMAIL` as Netlify environment variables. Never place the Resend API key in the Android app or website files. The hosted function must be tested before relying on email delivery.

## Project structure

- `app/src/main/java/com/aj/littlequestion/MainActivity.java` — Android WebView host.
- `app/src/main/assets/www/index.html` — the website interface and interaction code.
- `app/src/main/assets/www/app-config.js` — app-only offline/endpoint configuration.
- `app/src/main/assets/www/assets/` — bundled voice note and guitar music.

This ZIP contains Android Studio source code, not a compiled APK. It needs Android Studio/Android SDK to build the installable APK.
